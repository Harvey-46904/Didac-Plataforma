
<?php $__env->startSection('lista'); ?>
<h2>Estudiante</h2>
<br>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No Documento</th>
      <th scope="col">Nombres</th>
      <th scope="col">Apellidos</th>
      <th scope="col">Sexo</th>
      <th scope="col">Contacto</th>
      
    </tr>
  </thead>
  <tbody>
                        <tr>
                          <td><?php echo e($estudiantes->no_documento); ?></td>
                            <td><?php echo e($estudiantes->nombre); ?></td>
                            <td><?php echo e($estudiantes->apellido); ?></td>
                            <td><?php echo e($estudiantes->sexo); ?></td>
                            <td><?php echo e($estudiantes->contacto); ?></td>
                            
                           
                        </tr>
  </tbody>
</table>

<h2>Progreso de Juego</h2>
<hr>
<h3>Nivel Bajo</h3>
<div>
  <canvas id="myChart"  width="200px" height="40px"></canvas>
</div>
<hr>
<h3>Nivel Medio</h3>
<div>
  <canvas id="myChart1"  width="200px" height="40px"></canvas>
</div>
<hr>
<h3>Nivel Alto</h3>
<div>
  <canvas id="myChart2"  width="200px" height="40px"></canvas>
</div>

<h3>Resultados</h3>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Estudiante</th>
      <th scope="col">Juego</th>
      <th scope="col">Puntuacion</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $puntos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($punto->id); ?></td>
      <td><?php echo e($punto->id_estudiante); ?></td>
      <td>juego <?php echo e($punto->id_juego); ?></td>
      <td><?php echo e($punto->puntuacion); ?></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<hr>
<div class="container">
  <div class="row">
    <div class="col-md-12 text-center">
      <button class="btn btn-primary" >
        <i class="fas fa-book fa-sm"> Generar Reporte</i>
      </button>
      
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Didac-Plataforma\resources\views/lista_estudiante.blade.php ENDPATH**/ ?>