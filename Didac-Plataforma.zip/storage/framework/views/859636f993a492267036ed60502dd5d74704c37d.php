
<?php $__env->startSection('registro'); ?>
<h2>Registro Estudiantes</h2>
<br>
<?php if(Session::get('correcto')): ?>

                <div class="alert alert-success">
                    <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="tim-icons icon-simple-remove"></i>
                    </button>
                    <span><b></b> <?php echo \Session::get('correcto'); ?></span>
                  </div>
               
                <?php endif; ?>
<form method="POST" action="<?php echo e(route('registro_estudiantes')); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
      <label for="exampleFormControlInput1">No Documento</label>
      <input type="text" class="form-control" id="" placeholder="" name="no_documento" required>
    </div>
    <div class="form-group">
        <label for="exampleFormControlInput1">Nombres</label>
        <input type="text" class="form-control" id="" placeholder="" name="nombre" required>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Apellidos</label>
        <input type="text" class="form-control" id="" placeholder="" name="apellido" required>
      </div>
      <div class="form-group">
        <label for="exampleFormControlSelect1">Sexo</label>
        <select class="form-control" id="" name="sexo">
          <option>M</option>
          <option>F</option>
        </select>
      </div>
      <div class="form-group">
        <label for="exampleFormControlInput1">Contacto</label>
        <input type="text" class="form-control" id="" placeholder="" name="contacto" required>
      </div>
<input type="submit" value="Registrar" class="btn btn-primary mb-2">
</form>
<hr>
<h2>Lista de Estudiantes</h2>
<br>
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">No Documento</th>
      <th scope="col">Nombres</th>
      <th scope="col">Apellidos</th>
      <th scope="col">Sexo</th>
      <th scope="col">Contacto</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody>

    <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                        <tr>
                          <td><?php echo e($estudiante->no_documento); ?></td>
                            <td><?php echo e($estudiante->nombre); ?></td>
                            <td><?php echo e($estudiante->apellido); ?></td>
                            <td><?php echo e($estudiante->sexo); ?></td>
                            <td><?php echo e($estudiante->contacto); ?></td>
                            
                            <td><a href="<?php echo e(route("estudiantes_lista",$estudiante->id)); ?>" class="btn btn-primary">Mirar</a></td>
                        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Didac-Plataforma\resources\views/registro_estudiante.blade.php ENDPATH**/ ?>