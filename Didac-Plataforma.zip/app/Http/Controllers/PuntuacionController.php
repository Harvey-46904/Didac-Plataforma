<?php

namespace App\Http\Controllers;

use App\Models\puntuacion;
use Illuminate\Http\Request;

class PuntuacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\puntuacion  $puntuacion
     * @return \Illuminate\Http\Response
     */
    public function show(puntuacion $puntuacion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\puntuacion  $puntuacion
     * @return \Illuminate\Http\Response
     */
    public function edit(puntuacion $puntuacion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\puntuacion  $puntuacion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, puntuacion $puntuacion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\puntuacion  $puntuacion
     * @return \Illuminate\Http\Response
     */
    public function destroy(puntuacion $puntuacion)
    {
        //
    }

    public function agregar_puntuacion($estudiante,$juego,$puntuacion){

        $puntos=new puntuacion;
        $puntos->id_estudiante=$estudiante;
        $puntos->id_juego=$juego;
        $puntos->puntuacion=$puntuacion;
        $puntos->save();
        return "ok";
    }
}
